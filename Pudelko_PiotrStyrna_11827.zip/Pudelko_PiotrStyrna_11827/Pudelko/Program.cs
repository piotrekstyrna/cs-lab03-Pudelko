﻿using Box;

public static class Program{
    static void Main() {
        Pudelko k = new Pudelko(new List<double>() { 100, 200, 300 }, new List<UnitOfMeasure>() { UnitOfMeasure.centimeter, UnitOfMeasure.centimeter, UnitOfMeasure.centimeter });
        Pudelko l = new Pudelko(new List<double>() { 1, 2, 3 });

        Console.WriteLine(k.Equals(l));
        Console.WriteLine(k == l);
        Console.WriteLine(k != l);
    }
}