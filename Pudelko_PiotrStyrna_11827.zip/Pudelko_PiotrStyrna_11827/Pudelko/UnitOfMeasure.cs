﻿namespace Box {
    public enum UnitOfMeasure {
        milimeter,
        centimeter,
        meter
    }
}
