﻿using System.Collections;
using System.Text;

namespace Box {
    public partial class Pudelko {
        public IEnumerator<double> GetEnumerator() {
            return boxDimensions.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator() {
            return GetEnumerator();
        }

        public override bool Equals(object? obj) {
            if (obj == null)
                return false;

            var pudelko = obj as Pudelko;
            if (pudelko == null)
                return false;

            if (ToMeters(boxDimensions[0], unitOfMeasures[0]) != ToMeters(pudelko.boxDimensions[0], unitOfMeasures[0]))
                return false;
            if (ToMeters(boxDimensions[1], unitOfMeasures[1]) != ToMeters(pudelko.boxDimensions[1], unitOfMeasures[1]))
                return false;
            if (ToMeters(boxDimensions[2], unitOfMeasures[2]) != ToMeters(pudelko.boxDimensions[2], unitOfMeasures[2]))
                return false;
            return true;
        }

        public bool Equals(Pudelko? other) {
            if (ToMeters(boxDimensions[0], unitOfMeasures[0]) != ToMeters(other.boxDimensions[0], other.unitOfMeasures[0]))
                return false;
            if (ToMeters(boxDimensions[1], unitOfMeasures[1]) != ToMeters(other.boxDimensions[1], other.unitOfMeasures[1]))
                return false;
            if (ToMeters(boxDimensions[2], unitOfMeasures[2]) != ToMeters(other.boxDimensions[2], other.unitOfMeasures[2]))
                return false;
            return true;
        }

        public override int GetHashCode() {
            unchecked {
                int hash = 17;
                hash = hash * 23 + boxDimensions[0].GetHashCode();
                hash = hash * 23 + boxDimensions[1].GetHashCode();
                hash = hash * 23 + boxDimensions[2].GetHashCode();

                return hash;
            }
        }

        public override string ToString() {
            var output = new StringBuilder();

            output.Append(ToString(boxDimensions[0], unitOfMeasures[0]));
            output.Append(Split());
            output.Append(ToString(boxDimensions[1], unitOfMeasures[1]));
            output.Append(Split());
            output.Append(ToString(boxDimensions[2], unitOfMeasures[2]));
            return output.ToString();
        }

        public string ToString(string? format) {
            var output = new StringBuilder();

            if (string.IsNullOrEmpty(format) || format == "m") {
                double a = ConvertUnit(boxDimensions[0], unitOfMeasures[0], UnitOfMeasure.meter);
                double b = ConvertUnit(boxDimensions[1], unitOfMeasures[1], UnitOfMeasure.meter);
                double c = ConvertUnit(boxDimensions[2], unitOfMeasures[2], UnitOfMeasure.meter);

                output.Append(ToString(a));
                output.Append(Split());
                output.Append(ToString(b));
                output.Append(Split());
                output.Append(ToString(c));
            } else if (format == "cm") {
                double a = ConvertUnit(boxDimensions[0], unitOfMeasures[0], UnitOfMeasure.centimeter);
                double b = ConvertUnit(boxDimensions[1], unitOfMeasures[1], UnitOfMeasure.centimeter);
                double c = ConvertUnit(boxDimensions[2], unitOfMeasures[2], UnitOfMeasure.centimeter);

                output.Append(ToString(a, UnitOfMeasure.centimeter));
                output.Append(Split());
                output.Append(ToString(b, UnitOfMeasure.centimeter));
                output.Append(Split());
                output.Append(ToString(c, UnitOfMeasure.centimeter));
            } else if (format == "mm") {
                double a = ConvertUnit(boxDimensions[0], unitOfMeasures[0], UnitOfMeasure.milimeter);
                double b = ConvertUnit(boxDimensions[1], unitOfMeasures[1], UnitOfMeasure.milimeter);
                double c = ConvertUnit(boxDimensions[2], unitOfMeasures[2], UnitOfMeasure.milimeter);

                output.Append(ToString(a, UnitOfMeasure.milimeter));
                output.Append(Split());
                output.Append(ToString(b, UnitOfMeasure.milimeter));
                output.Append(Split());
                output.Append(ToString(c, UnitOfMeasure.milimeter));
            } else {
                throw new FormatException($"Input format \"{format}\" cannot be resolved.");
            }

            return output.ToString();
        }

        string ToString(double number, UnitOfMeasure unit = UnitOfMeasure.meter) {
            var output = new StringBuilder();

            double rounded = Round(number, unit);
            output.Append(PadZeros(rounded, unit));
            output.Append(' ');
            output.Append(ToString(unit));
            return output.ToString();

            string ToString(UnitOfMeasure unit) {
                switch (unit) {
                    case UnitOfMeasure.milimeter:
                        return "mm";
                    case UnitOfMeasure.centimeter:
                        return "cm";
                    case UnitOfMeasure.meter:
                        return "m";
                }

                throw new ArgumentException($"Invalid argument: {unit}");
            }
        }

        string PadZeros(double number, UnitOfMeasure unit) {
            switch (unit) {
                case UnitOfMeasure.milimeter:
                    return number.ToString("0");
                case UnitOfMeasure.centimeter:
                    return number.ToString("F1");
                case UnitOfMeasure.meter:
                    return number.ToString("F3");
            }

            throw new ArgumentException($"Invalid argument: {unit}");
        }

        double Round(double number, UnitOfMeasure unit = UnitOfMeasure.meter) {
            switch (unit) {
                case UnitOfMeasure.milimeter:
                    return Math.Round(number, 0, MidpointRounding.ToZero);
                case UnitOfMeasure.centimeter:
                    return Math.Round(number, 1, MidpointRounding.ToZero);
                case UnitOfMeasure.meter:
                    return Math.Round(number, 3, MidpointRounding.ToZero);
            }

            throw new FormatException($"Input actualUnit \"{unit}\" cannot be resolved.");
        }

        double ToMeters(double number, UnitOfMeasure actualUnit) {
            switch (actualUnit) {
                case UnitOfMeasure.milimeter:
                    return Round(number / 1000);
                case UnitOfMeasure.centimeter:
                    return Round(number / 100);
                case UnitOfMeasure.meter:
                    return Round(number);
            }

            throw new FormatException($"Input actualUnit \"{actualUnit}\" cannot be resolved.");
        }

        double ConvertUnit(double number, UnitOfMeasure current, UnitOfMeasure target) {
            switch (current) {
                case UnitOfMeasure.milimeter:
                    switch (target) {
                        case UnitOfMeasure.centimeter:
                            return number / 10;
                        case UnitOfMeasure.meter:
                            return number / 1000;
                    }
                    break;

                case UnitOfMeasure.centimeter:
                    switch (target) {
                        case UnitOfMeasure.milimeter:
                            return number * 10;
                        case UnitOfMeasure.meter:
                            return number / 100;
                    }
                    break;

                case UnitOfMeasure.meter:
                    switch (target) {
                        case UnitOfMeasure.milimeter:
                            return number * 1000;
                        case UnitOfMeasure.centimeter:
                            return number * 100;
                    }
                    break;
            }

            return number;
        }

        string Split() => " × ";
    }
}
