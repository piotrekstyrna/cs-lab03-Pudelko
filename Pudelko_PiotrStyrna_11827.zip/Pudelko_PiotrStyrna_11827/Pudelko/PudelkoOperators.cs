﻿using Microsoft.VisualBasic.CompilerServices;

namespace Box {
    public partial class Pudelko {
        public static Pudelko Parse(string input) {
            input = input.Replace('.', ',');
            var splitted = input.Split(' ');
            if (splitted.Length != 8)
                throw new ArgumentOutOfRangeException("Invalid number of arguments in parsed string.");

            var diameters = new List<double>();
            var units = new List<UnitOfMeasure>();

            for (int i = 0; i < splitted.Length; i+= 3) {
                if (!double.TryParse(splitted[i], out double number))
                    throw new ArgumentException($"Invalid argument: {splitted[i]}");

                diameters.Add(number);
                units.Add(GetUnit(splitted[i + 1]));

            }

            return new Pudelko(diameters, units);

            UnitOfMeasure GetUnit(string input) {
                if (input == "m")
                    return UnitOfMeasure.meter;
                if (input == "cm")
                    return UnitOfMeasure.centimeter;
                if (input == "mm")
                    return UnitOfMeasure.milimeter;

                throw new ArgumentException($"Invalid argument: {input}");
            }

        }

        public static implicit operator Pudelko(ValueTuple<int, int, int> tuple) {
            var dims = new List<double>() {
                tuple.Item1,
                tuple.Item2,
                tuple.Item3
            };

            var units = new List<UnitOfMeasure>() {
                UnitOfMeasure.milimeter,
                UnitOfMeasure.milimeter,
                UnitOfMeasure.milimeter
            };

            return new Pudelko(dims, units);
        }

        public static explicit operator double[](Pudelko box) {
            return new Double[] {box.A, box.B, box.C};
        }

        public static Pudelko operator +(Pudelko a, Pudelko b) {
            var newDims = new List<double>();
            newDims.Add(a.boxDimensions[0] + b.boxDimensions[0]);
            newDims.Add(a.boxDimensions[1] + b.boxDimensions[1]);
            newDims.Add(a.boxDimensions[2] + b.boxDimensions[2]);
            return new Pudelko(newDims, new List<UnitOfMeasure>());
        }

        public static bool operator ==(Pudelko a, Pudelko b) {
            return a.Equals(b);
        }

        public static bool operator !=(Pudelko a, Pudelko b) {
            return !a.Equals(b);
        }
    }
}
