﻿using System.Collections;

namespace Box {
    public sealed partial class Pudelko : IEquatable<Pudelko>, IEnumerable<double> {
        public double Objetosc => volume;
        public double Pole => field;
        public double A => Round(ToMeters(boxDimensions[0], unitOfMeasures[0]));
        public double B => Round(ToMeters(boxDimensions[1], unitOfMeasures[1]));
        public double C => Round(ToMeters(boxDimensions[2], unitOfMeasures[2]));

        //double a { get; }
        //double b { get; }
        //double c { get; }
        double volume { get; }
        double field { get; }

        readonly List<UnitOfMeasure> unitOfMeasures;
        readonly List<double> boxDimensions;

        public double this[int i] => Round(boxDimensions[i], unitOfMeasures[i]);

        public Pudelko(List<double> dimensions = null, List<UnitOfMeasure> units = null) {
            const int dimensionsNumber = 3;

            if (dimensions == null)
                dimensions = new List<double>();

            if (units == null)
                units = new List<UnitOfMeasure>();

            boxDimensions = new List<double>(dimensionsNumber);
            unitOfMeasures = new List<UnitOfMeasure>(dimensionsNumber);

            for (int i = 0; i < dimensionsNumber; i++) {
                if (i >= dimensions.Count) {
                    if (i >= units.Count) {
                        boxDimensions.Add(DefaultValue(UnitOfMeasure.meter));
                        unitOfMeasures.Add(UnitOfMeasure.meter);
                    } else {
                        boxDimensions.Add(DefaultValue(units[i]));
                        unitOfMeasures.Add(units[i]);
                    }

                    continue;
                }

                boxDimensions.Add(dimensions[i]);
                unitOfMeasures.Add(i >= units.Count ? UnitOfMeasure.meter : units[i]);

                if (ToMeters(dimensions[i], unitOfMeasures[i]) <= 0 || ToMeters(dimensions[i], unitOfMeasures[i]) > 10)
                    throw new ArgumentOutOfRangeException($"Arg {dimensions[i]} is out of measure.");
            }

            field = CalculateField();
            volume = CalculateVolume();

            double CalculateVolume() {
                var a = ConvertUnit(boxDimensions[0], unitOfMeasures[0], UnitOfMeasure.meter);
                var b = ConvertUnit(boxDimensions[1], unitOfMeasures[1], UnitOfMeasure.meter);
                var c = ConvertUnit(boxDimensions[2], unitOfMeasures[2], UnitOfMeasure.meter);
                return Math.Round(a * b * c, 9, MidpointRounding.AwayFromZero);
            }

            double CalculateField() {
                var a = ConvertUnit(boxDimensions[0], unitOfMeasures[0], UnitOfMeasure.meter);
                var b = ConvertUnit(boxDimensions[1], unitOfMeasures[1], UnitOfMeasure.meter);
                var c = ConvertUnit(boxDimensions[2], unitOfMeasures[2], UnitOfMeasure.meter);

                var ab2 = Math.Round(2 * a * b);
                var ac2 = Math.Round(2 * a * c);
                var bc2 = Math.Round(2 * b * c);
                return Math.Round(ab2 + ac2 + bc2, 6, MidpointRounding.AwayFromZero);
            }
        }

        float DefaultValue(UnitOfMeasure unit) {
            switch (unit) {
                case UnitOfMeasure.milimeter:
                    return 100;
                case UnitOfMeasure.centimeter:
                    return 10;
                case UnitOfMeasure.meter:
                    return 0.1f;
            }

            throw new FormatException($"Input unit \"{unit}\" cannot be resolved.");
        }
    }
}
